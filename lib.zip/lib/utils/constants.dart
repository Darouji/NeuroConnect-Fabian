// Archivo: lib/utils/constants.dart

class AppConstants {
  // Aquí defino el correo del administrador.
  // Lo uso para verificar quién tiene permiso de ver el botón de "subir" en el Home.
  static const String adminEmail = 'fabian.garcia18m@gmail.com';
}
